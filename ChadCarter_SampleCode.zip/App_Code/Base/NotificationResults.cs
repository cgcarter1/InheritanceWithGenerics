﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for NotificationResults
/// </summary>
public class NotificationResults<T>
{
    public NotificationResults() { }
    public NotificationResults(T person, string message) : this()
    {
        this.Person = person;
        this.Message = message;
    }
    
    public T Person { get; set; }
    public string Message { get; set; }
}